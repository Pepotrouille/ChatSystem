package model;

public class Signal{
	
	
	//---------------------------Attributs-------------------------
	
	
	//---------------------------Méthodes-------------------------
	
	//----------Constructeur
	
	public Signal() { 				
		
	}

	//----------Getters
	
	//----------Setters
	
	//----------Autres Méthodes
	
	public String ToString() {
		return "S";
	}
	
}
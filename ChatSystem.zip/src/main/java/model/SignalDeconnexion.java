package model;

public class SignalDeconnexion extends Signal{
	
	
	//---------------------------Attributs-------------------------
	
	
	//---------------------------Méthodes-------------------------
	
	//----------Constructeur
	
	public SignalDeconnexion() { 				
		
	}

	//----------Getters
	
	//----------Setters
	
	//----------Autres Méthodes

	
	public String ToString() {
		return "D";
	}
}